package com.sum.mealplatform.bean;

public class MenuInfo {
	
	private int menu_ID;
	private int r_ID;
	private int pid;
	private String name;
	private int price;
	private String desc;
	private int stock;
	private String tag;
	private int sort;
	private int month_sales;
	private int last_month_sales;
	
	
	public int getMenu_ID() {
		return menu_ID;
	}
	public void setMenu_ID(int menu_ID) {
		this.menu_ID = menu_ID;
	}
	public int getR_ID() {
		return r_ID;
	}
	public void setR_ID(int r_ID) {
		this.r_ID = r_ID;
	}
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	public int getStock() {
		return stock;
	}
	public void setStock(int stock) {
		this.stock = stock;
	}
	public String getTag() {
		return tag;
	}
	public void setTag(String tag) {
		this.tag = tag;
	}
	public int getSort() {
		return sort;
	}
	public void setSort(int sort) {
		this.sort = sort;
	}
	public int getMonth_sales() {
		return month_sales;
	}
	public void setMonth_sales(int month_sales) {
		this.month_sales = month_sales;
	}
	public int getLast_month_sales() {
		return last_month_sales;
	}
	public void setLast_month_sales(int last_month_sales) {
		this.last_month_sales = last_month_sales;
	}
	

}
