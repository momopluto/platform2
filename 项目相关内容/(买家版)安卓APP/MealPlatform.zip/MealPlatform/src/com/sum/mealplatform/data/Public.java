package com.sum.mealplatform.data;

import java.util.ArrayList;
import java.util.List;

import android.text.TextUtils;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.sum.mealplatform.AppContext;
import com.sum.mealplatform.bean.AddressInfo;
import com.sum.mealplatform.bean.UserInfo;
import com.sum.mealplatform.util.SpUtil;

public class Public {
	private Public() {
	}

	private static final String KEY_IS_FIRST_TIME_ENTER = "isFirstTimeEnter";

	public static boolean isFirstTimeEnter() {
		boolean isFirstTimeEnter = (boolean) SpUtil.get(
				AppContext.getInstance(), KEY_IS_FIRST_TIME_ENTER, true);
		return isFirstTimeEnter;
	}

	public static void setFirstTimeEnterToFalse() {
		SpUtil.put(AppContext.getInstance(), KEY_IS_FIRST_TIME_ENTER, false);
	}

	/**
	 * UserInfo
	 */
	public static final String KEY_USER_INFO = "userinfo";

	public static final UserInfo userInfo;
	static {
		userInfo = new UserInfo();
		List<AddressInfo> addressInfos = new ArrayList<AddressInfo>();
		userInfo.setAddr(addressInfos);
	}

	public static void readUserInfoFromLocal() {
		String json = (String) SpUtil.get(AppContext.getInstance(),
				Public.KEY_USER_INFO, "");
		if (!TextUtils.isEmpty(json)) {
			UserInfo info = Public.getGson().fromJson(json,
					new TypeToken<UserInfo>() {
					}.getType());
			setUserInfo(info);
		}
	}

	private static void setUserInfo(UserInfo info) {
		userInfo.setClient_ID(info.getClient_ID());
		userInfo.setName(info.getName());
		userInfo.setPhone(info.getPhone());
		userInfo.getAddr().addAll(info.getAddr());
	}

	public static void saveUserInfoToLocal() {
		if (userInfo != null) {
			String json = Public.getGson().toJson(userInfo,
					new TypeToken<UserInfo>() {
					}.getType());
			SpUtil.put(AppContext.getInstance(), Public.KEY_USER_INFO, json,
					true);
		}
	}

	/**
	 * Gson
	 */
	private static Gson gson = null;

	public static Gson getGson() {
		if (null == gson) {
			gson = new Gson();
		}
		return gson;
	}

}
