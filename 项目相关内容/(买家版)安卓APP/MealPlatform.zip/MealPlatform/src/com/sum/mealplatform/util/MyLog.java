package com.sum.mealplatform.util;

import android.util.Log;

/**
 * Log统一管理类
 * 
 *
 */
public final class MyLog {
	private MyLog() {
	}

	public static final String DEFAULT_TAG = "MyLog";
	public static boolean isDebug = true;

	public static void v(String str) {
		if (isDebug)
			Log.v(DEFAULT_TAG, str);
	}

	public static void i(String str) {
		if (isDebug)
			Log.i(DEFAULT_TAG, str);
	}

	public static void d(String str) {
		if (isDebug)
			Log.d(DEFAULT_TAG, str);
	}

	public static void e(String str) {
		if (isDebug)
			Log.e(DEFAULT_TAG, str);
	}

	public static void i(String tag, String msg) {
		if (isDebug)
			Log.e(tag, msg);
	}

	public static void d(String tag, String msg) {
		if (isDebug)
			Log.e(tag, msg);
	}

	public static void e(String tag, String msg) {
		if (isDebug)
			Log.e(tag, msg);
	}

	public static void v(String tag, String msg) {
		if (isDebug)
			Log.e(tag, msg);
	}

}
