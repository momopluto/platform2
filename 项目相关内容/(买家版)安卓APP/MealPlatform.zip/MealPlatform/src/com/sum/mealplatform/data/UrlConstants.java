package com.sum.mealplatform.data;

public class UrlConstants {
	private UrlConstants() {
	}

	public static final int srcid = 10086;

	/**
	 * Get REQUEST
	 */
	public static final String RESTAURANT_LIST_URL = "http://momopluto.xicp.net/platform2/index.php/Client/Restaurant/lists.html?srcid=10086";

	public static final String RESTAURANT_INFO_URL = "http://momopluto.xicp.net/platform2/index.php/Client/Restaurant/info.html?r_ID=302580000&srcid=10086";

	/**
	 * POST REQUEST
	 */
	// argument:r_ID
	public static final String MENU_URL = "http://momopluto.xicp.net/platform2/index.php/Client/Order/menu.html?srcid=10086";

	// argument:phone
	public static final String CHECK_PHONE_URL = "http://momopluto.xicp.net/platform2/index.php/Client/Order/is_phone_exists.html?srcid=10086";

	// argument:client_ID and address
	public static final String ADD_ADDRESS_URL = "http://momopluto.xicp.net/platform2/index.php/Client/Order/add_addr.html?srcid=10086";

	// argument:address_ID and address
	public static final String UPDATE_ADDRESS_URL = "http://127.0.0.1:8080/platform2/index.php/Client/Order/update_addr.html?srcid=10086";

	// 查询订单详情argument:r_ID
	public static final String RESTAURANT_STATUS_URL = "http://momopluto.xicp.net/platform2/index.php/Client/Restaurant/getStatus.html?srcid=10086";

	// 下订单
	public static final String ORDER_DONE_URL = "http://momopluto.xicp.net//platform2/index.php/Client/Order/done.html?srcid=10086";

	// 查看我的订单argument:client_ID
	public static final String MY_ORDERS_URL = "http://momopluto.xicp.net/platform2/index.php/Client/Order/myOrder.html?srcid=10086";

	// 查询订单详情argument:guid
	public static final String ORDER_DETAIL_URL = "http://momopluto.xicp.net/platform2/index.php/Client/Order/detail.html?srcid=10086";

	// 注册argument:phone and name
	public static final String CLIENT_REGISTER_URL = "http://momopluto.xicp.net/platform2/index.php/Client/User/reg.html?srcid=10086";

	// 客户登录argument:phone
	public static final String CLIENT_LOGIN_URL = "http://momopluto.xicp.net/platform2/index.php/Client/User/login.html?srcid=10086";
}
