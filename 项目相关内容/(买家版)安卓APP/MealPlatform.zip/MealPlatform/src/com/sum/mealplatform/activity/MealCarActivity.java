package com.sum.mealplatform.activity;

import java.util.List;

import com.joanzapata.android.BaseAdapterHelper;
import com.joanzapata.android.QuickAdapter;
import com.sum.mealplatform.R;
import com.sum.mealplatform.bean.OrderInfo;
import com.sum.mealplatform.bean.OrderMenuItem;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewStub;
import android.widget.ListView;
import android.widget.TextView;

public class MealCarActivity extends Activity implements OnClickListener {

	private static final int REQUEST_CODE = 0x123;

	private ListView listView;
	private QuickAdapter<OrderMenuItem> adapter;

	private TextView countTextView;
	private TextView totalTextView;
	private int orderCount;

	private OrderInfo orderInfo;

	private View errorPagerView;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.meal_car_activity);
		getWindow().setBackgroundDrawable(null);

		getDataFromIntent();

		initView();

	}

	private void getDataFromIntent() {
		Intent intent = getIntent();
		Bundle bundle = intent.getBundleExtra("BUNDLE");
		orderInfo = (OrderInfo) bundle.get("ORDER_INFO");
	}

	private void initView() {

		findViewById(R.id.iv_meal_car_back).setOnClickListener(this);
		findViewById(R.id.btn_meal_car_submit).setOnClickListener(this);

		countTextView = (TextView) findViewById(R.id.tv_meal_car_count);
		List<OrderMenuItem> list = orderInfo.getItem();
		int size = list.size();
		for (int i = 0; i < size; i++) {
			orderCount += list.get(i).getCount();
		}
		countTextView.setText("" + orderCount);

		totalTextView = (TextView) findViewById(R.id.tv_meal_car_total);
		totalTextView.setText("" + orderInfo.getTotal());

		listView = (ListView) findViewById(R.id.list_meal_car);
		adapter = new QuickAdapter<OrderMenuItem>(this, R.layout.meal_car_item,
				orderInfo.getItem()) {

			@Override
			protected void convert(BaseAdapterHelper helper, OrderMenuItem item) {
				helper.setText(R.id.tv_meal_car_menu_name, item.getName());
				helper.setText(R.id.tv_meal_car_menu_count,
						"X" + item.getCount());
				helper.setText(R.id.tv_meal_car_menu_price,
						"￥" + item.getPrice());

				helper.setOnClickListener(R.id.tv_meal_car_add,
						MealCarActivity.this);
				helper.setTag(R.id.tv_meal_car_add, helper.getPosition());
				helper.setOnClickListener(R.id.tv_meal_car_reduce,
						MealCarActivity.this);
				helper.setTag(R.id.tv_meal_car_reduce, helper.getPosition());

				helper.setOnClickListener(R.id.iv_meal_car_delete,
						MealCarActivity.this);
				helper.setTag(R.id.iv_meal_car_delete, helper.getPosition());
			}
		};
		listView.setAdapter(adapter);
	}

	@Override
	public void onClick(View v) {
		int position = 0;
		switch (v.getId()) {
		case R.id.iv_meal_car_back:
			finish();
			break;

		case R.id.tv_meal_car_add:
			position = (int) v.getTag();
			addMenuCount(position);
			break;
		case R.id.tv_meal_car_reduce:
			position = (int) v.getTag();
			reduceMenuCount(position);
			break;
		case R.id.iv_meal_car_delete:
			position = (int) v.getTag();
			removeMenu(position);
			break;
		case R.id.btn_meal_car_submit:
			Bundle bundle = new Bundle();
			bundle.putSerializable("ORDER_INFO", orderInfo);
			Intent intent = new Intent(MealCarActivity.this,
					OrderActivity.class);
			intent.putExtras(bundle);
			startActivityForResult(intent, REQUEST_CODE);
			break;

		}

	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (requestCode == REQUEST_CODE) {
			if (resultCode == RESULT_OK) {
				setResult(RESULT_OK);
				finish();
			}
		}
	}

	private void removeMenu(int position) {
		List<OrderMenuItem> list = orderInfo.getItem();

		OrderMenuItem menuItem = list.get(position);

		int crrMenuCount = menuItem.getCount();
		int menuPrice = menuItem.getPrice();
		int crrTotal = orderInfo.getTotal();
		crrTotal -= crrMenuCount * menuPrice;
		orderInfo.setTotal(crrTotal);
		orderCount -= crrMenuCount;

		menuItem.setCount(0);
		menuItem.setTotal(0);

		list.remove(position);
		if (list.size() == 0) {
			showErrorPagerView();
		}

		countTextView.setText("" + orderCount);
		totalTextView.setText("" + orderInfo.getTotal());

		adapter.remove(position);
		adapter.notifyDataSetChanged();
	}

	private void reduceMenuCount(int position) {
		List<OrderMenuItem> list = orderInfo.getItem();

		OrderMenuItem menuItem = list.get(position);
		int crrMenuCount = menuItem.getCount();
		crrMenuCount--;
		menuItem.setCount(crrMenuCount);
		int crrMenuTotal = menuItem.getTotal();
		crrMenuTotal -= menuItem.getPrice();
		menuItem.setTotal(crrMenuTotal);

		int crrTotal = orderInfo.getTotal();
		crrTotal -= menuItem.getPrice();
		orderInfo.setTotal(crrTotal);

		orderCount--;
		countTextView.setText("" + orderCount);
		totalTextView.setText("" + orderInfo.getTotal());

		if (crrMenuCount == 0) {
			adapter.remove(position);
			list.remove(position);
			if (list.size() == 0) {
				showErrorPagerView();
			}
		}

		adapter.notifyDataSetChanged();
	}

	private void addMenuCount(int position) {
		OrderMenuItem menuItem = orderInfo.getItem().get(position);
		int crrMenuCount = menuItem.getCount();
		crrMenuCount++;
		menuItem.setCount(crrMenuCount);
		int crrMenuTotal = menuItem.getTotal();
		crrMenuTotal += menuItem.getPrice();
		menuItem.setTotal(crrMenuTotal);

		int crrTotal = orderInfo.getTotal();
		crrTotal += menuItem.getPrice();
		orderInfo.setTotal(crrTotal);

		orderCount++;
		countTextView.setText("" + orderCount);
		totalTextView.setText("" + orderInfo.getTotal());

		adapter.notifyDataSetChanged();
	}

	private void showErrorPagerView() {
		if (errorPagerView == null) {
			ViewStub viewStub = (ViewStub) findViewById(R.id.stub_meal_car_err);
			errorPagerView = viewStub.inflate();
		}
	}

}
