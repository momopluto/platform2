package com.sum.mealplatform.fragment;

import java.lang.ref.WeakReference;
import java.util.List;

import android.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;

import com.google.gson.reflect.TypeToken;
import com.joanzapata.android.BaseAdapterHelper;
import com.joanzapata.android.QuickAdapter;
import com.sum.mealplatform.AppContext;
import com.sum.mealplatform.R;
import com.sum.mealplatform.activity.MainActivity.ShowDrawerListener;
import com.sum.mealplatform.activity.MenuActivity;
import com.sum.mealplatform.bean.RestaurantInfo;
import com.sum.mealplatform.bean.RestaurantListInfo;
import com.sum.mealplatform.bean.Result;
import com.sum.mealplatform.data.Public;
import com.sum.mealplatform.data.UrlConstants;
import com.sum.mealplatform.helper.SerializableList;
import com.sum.mealplatform.util.HttpUtil;
import com.sum.mealplatform.util.MyLog;
import com.sum.mealplatform.util.MyToast;
import com.sum.mealplatform.util.NetUtil;
import com.sum.mealplatform.view.CustomStateItemView;
import com.sum.mealplatform.view.SwipeRefreshLayout;

public class RestaurantListFragment extends Fragment implements
		OnItemClickListener, OnClickListener {

	private SwipeRefreshLayout swipeRefreshLayout;
	private ListView listView;
	private QuickAdapter<RestaurantInfo> adapter;

	private ShowDrawerListener showDrawerListener;

	public void setShowDrawerListener(ShowDrawerListener listener) {
		showDrawerListener = listener;
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {

		View rootView = inflater.inflate(R.layout.main_restaurant_list,
				container, false);

		rootView.findViewById(R.id.iv_restaurant_nav_options)
				.setOnClickListener(this);
		rootView.findViewById(R.id.tv_restaurant_nav_change)
				.setOnClickListener(this);
		initContentLayout(rootView);

		return rootView;
	}

	private void initContentLayout(View rootView) {

		swipeRefreshLayout = (SwipeRefreshLayout) rootView
				.findViewById(R.id.swiperefresh_restaurant);
		swipeRefreshLayout
				.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
					@Override
					public void onRefresh() {

						myUpdateOperation();
					}
				});

		listView = (ListView) rootView.findViewById(R.id.listview_restaurant);
		adapter = new QuickAdapter<RestaurantInfo>(getActivity(),
				R.layout.main_restaurant_item, null) {

			@Override
			protected void convert(BaseAdapterHelper helper, RestaurantInfo item) {

				helper.setImageResource(R.id.iv_restaurant_icon,
						R.drawable.ic_launcher);
				helper.setText(R.id.tv_restaurant_name, item.getName());
				helper.setText(R.id.tv_restaurant_during_open,
						item.isDuringOpen() ? "接受预订" : "暂不接受订单");
				helper.setText(
						R.id.tv_restaurant_desc,
						"月售" + item.getMonth_sales() + "单/"
								+ item.getAgent_fee() + "元起送/"
								+ item.getTime_1_open() + "开始营业");

				CustomStateItemView customStateItemView = helper
						.getView(R.id.rl_restaurant_item);
				if (item.isDuringOpen()) {
					customStateItemView.setCustomState(true);
				} else {
					customStateItemView.setCustomState(false);
				}

			}

		};
		listView.setAdapter(adapter);
		listView.setOnItemClickListener(this);

		swipeRefreshLayout.startLoadingAnimForRefresh();
	}

	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position,
			long id) {

		CustomStateItemView itemView = (CustomStateItemView) view;
		if (itemView != null && itemView.getCustomState()) {

//			MyLog.e("RestaurantFragment : on click position = " + position);

			Intent intent = new Intent(getActivity(), MenuActivity.class);
			Bundle bundle = new Bundle();
			bundle.putInt("RESTAURANT_ID", adapter.getItem(position).getR_ID());
			bundle.putString("RESTAURANT_NAME", adapter.getItem(position)
					.getName());
			bundle.putInt("RESTAURANT_AGENT_FEE", adapter.getItem(position)
					.getAgent_fee());
			intent.putExtra("ARGUMENTS", bundle);
			startActivity(intent);
		}

	}

	/**
	 * update content
	 */
	private void myUpdateOperation() {

		if (!NetUtil.isConnected(AppContext.getInstance())) {
			swipeRefreshLayout.setRefreshing(false);
			MyToast.showShort(AppContext.getInstance(), "网络没有连接哦！");
			return;
		}

		HttpUtil.doGetAsyn(UrlConstants.RESTAURANT_LIST_URL,
				new HttpUtil.CallBack() {

					@Override
					public void onRequestComplete(String result) {

						if (TextUtils.isEmpty(result)) {
							return;
						}

						List<RestaurantInfo> datas = resultToRestaurantInfoList(result);
						if (null == datas || datas.size() == 0) {
							return;
						}

						SerializableList<RestaurantInfo> list = new SerializableList<RestaurantInfo>();
						list.setList(datas);

						Message msg = mHandler.obtainMessage(0x123);
						Bundle bundle = new Bundle();
						bundle.putSerializable("list", list);
						msg.setData(bundle);
						mHandler.sendMessage(msg);

					}
				});
	}

	private static List<RestaurantInfo> resultToRestaurantInfoList(String json) {
		Result<RestaurantListInfo> result = Public.getGson().fromJson(json,
				new TypeToken<Result<RestaurantListInfo>>() {
				}.getType());

		RestaurantListInfo twoList = result.getData();
		int open_count = twoList.getOpen_rsts().size();
		for (int i = 0; i < open_count; i++) {
			twoList.getOpen_rsts().get(i).setDuringOpen(true);
		}
		int close_count = twoList.getClose_rsts().size();
		for (int i = 0; i < close_count; i++) {
			twoList.getClose_rsts().get(i).setDuringOpen(false);
		}

		List<RestaurantInfo> list = twoList.getOpen_rsts();
		list.addAll(twoList.getClose_rsts());

		return list;
	}

	/*
	 * 
	 */
	private MyHandler mHandler = new MyHandler(this);

	/**
	 *  
	 */
	static class MyHandler extends Handler {
		WeakReference<Fragment> mFragmentReference;

		MyHandler(Fragment fragment) {
			mFragmentReference = new WeakReference<Fragment>(fragment);
		}

		@Override
		public void handleMessage(Message msg) {
			if (msg.what == 0x123) {
				final RestaurantListFragment fragment = (RestaurantListFragment) mFragmentReference
						.get();
				if (fragment != null) {

					// update data
					Bundle bundle = msg.getData();
					if (bundle != null) {
						@SuppressWarnings("unchecked")
						SerializableList<RestaurantInfo> list = (SerializableList<RestaurantInfo>) bundle
								.getSerializable("list");
						List<RestaurantInfo> newData = list.getList();

						int i = 0;
						while (i < newData.size()) {
							boolean changed = false;
							int oldDataSize = fragment.adapter.getCount();
							for (int j = 0; j < oldDataSize; j++) {
								if (newData.get(i).getR_ID() == fragment.adapter
										.getItem(j).getR_ID()) {
									newData.remove(i);
									changed = true;
									break;
								}
							}
							if (!changed) {
								i++;
							}
						}

						if (newData != null && newData.size() > 0) {
							fragment.adapter.addAll(newData);
						} else {
							MyToast.showShort(AppContext.getInstance(),
									"没有更多的餐厅啦！");
						}
					}

					fragment.swipeRefreshLayout.setRefreshing(false);
				}
			}
		}
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.iv_restaurant_nav_options:
			if (showDrawerListener != null) {
				showDrawerListener.showDrawer();
			}
			break;
		case R.id.tv_restaurant_nav_change:

			break;
		}

	}

}
