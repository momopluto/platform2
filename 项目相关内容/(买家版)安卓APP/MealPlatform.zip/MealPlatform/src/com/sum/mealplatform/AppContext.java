package com.sum.mealplatform;

import android.app.Application;

import com.sum.mealplatform.data.Public;

public class AppContext extends Application {

	private static AppContext mInstance = null;

	public static AppContext getInstance() {
		return mInstance;
	}

	@Override
	public void onCreate() {
		super.onCreate();
		mInstance = this;

		Public.readUserInfoFromLocal();

	}

}
