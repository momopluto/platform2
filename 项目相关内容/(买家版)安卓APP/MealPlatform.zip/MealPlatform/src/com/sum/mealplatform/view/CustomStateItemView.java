package com.sum.mealplatform.view;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.RelativeLayout;

import com.sum.mealplatform.R;

public class CustomStateItemView extends RelativeLayout {

	private static final int[] STATE_CUSTOM = { R.attr.state_custom_item };
	private boolean customState = false;

	public CustomStateItemView(Context context, AttributeSet attrs) {
		super(context, attrs);
	}

	public void setCustomState(boolean state) {
		if (this.customState != state) {
			customState = state;
			refreshDrawableState();
		}
	}

	public boolean getCustomState() {
		return customState;
	}

	@Override
	protected int[] onCreateDrawableState(int extraSpace) {
		if (customState) {
			final int[] drawableState = super
					.onCreateDrawableState(extraSpace + 1);
			mergeDrawableStates(drawableState, STATE_CUSTOM);
			return drawableState;
		}
		return super.onCreateDrawableState(extraSpace);
	}

}