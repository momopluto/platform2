package com.sum.mealplatform.activity;

import java.util.List;

import android.app.Activity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.TextView;

import com.joanzapata.android.BaseAdapterHelper;
import com.joanzapata.android.QuickAdapter;
import com.sum.mealplatform.R;
import com.sum.mealplatform.bean.AddressInfo;
import com.sum.mealplatform.bean.UserInfo;
import com.sum.mealplatform.data.Public;
import com.sum.mealplatform.dialog.DeleteDialogFragment;
import com.sum.mealplatform.dialog.DeleteDialogFragment.DeleteListener;
import com.sum.mealplatform.dialog.InputDialogData;
import com.sum.mealplatform.dialog.InputDialogFragment;
import com.sum.mealplatform.dialog.InputDialogFragment.DataChangedListener;
import com.sum.mealplatform.view.ListViewForScrollView;

public class UserInfoActivity extends Activity implements OnClickListener,
		OnItemLongClickListener, DataChangedListener {

	private UserInfo userinfo;// 在初始化数据时，引用Public.userinfo

	private static final int REQUEST_CODE_INPUT_NAME = 0x1001;
	private static final int REQUEST_CODE_INPUT_PHONE = 0x1002;
	private static final int REQUEST_CODE_INPUT_ADDRESS = 0x1003;
	private static final int REQUEST_CODE_DELETE_ADDRESS = 0x1004;

	private TextView nameTextView;
	private TextView phoneTextView;
	private ListViewForScrollView listview;
	private QuickAdapter<AddressInfo> adapter;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE); // 去掉ActionBar
		setContentView(R.layout.userinfo_activity);
		getWindow().setBackgroundDrawable(null); // 去掉系统背景

		initView();

		initData();
	}

	@Override
	public void finish() {
		super.finish();
		overridePendingTransition(0, R.anim.userinfo_activity_exit);
	}

	private void initView() {
		findViewById(R.id.iv_userinfo_back).setOnClickListener(this);
		findViewById(R.id.btn_userinfo_head).setOnClickListener(this);
		findViewById(R.id.btn_userinfo_name).setOnClickListener(this);
		findViewById(R.id.btn_userinfo_phone).setOnClickListener(this);
		findViewById(R.id.btn_userinfo_address).setOnClickListener(this);

		nameTextView = (TextView) findViewById(R.id.tv_userinfo_name);
		phoneTextView = (TextView) findViewById(R.id.tv_userinfo_phone);

		listview = (ListViewForScrollView) findViewById(R.id.listview_userinfo_address);
		adapter = new QuickAdapter<AddressInfo>(this,
				R.layout.userinfo_address_item, null) {

			@Override
			protected void convert(BaseAdapterHelper helper, AddressInfo item) {
				helper.setText(R.id.tv_address_item, item.getAddress());
			}
		};
		listview.setAdapter(adapter);
		listview.setOnItemLongClickListener(this);
	}

	private void initData() {
		userinfo = Public.userInfo;
		displayUserName();
		displayUserPhone();
		displayUserAddress();
	}

	/**
	 * 显示用户姓名
	 */
	private void displayUserName() {
		if (!TextUtils.isEmpty(userinfo.getName())) {
			nameTextView.setText(userinfo.getName());
		}
	}

	/**
	 * 显示用户手机号
	 */
	private void displayUserPhone() {
		if (!TextUtils.isEmpty(userinfo.getPhone())) {
			phoneTextView.setText(userinfo.getPhone());
		}
	}

	/**
	 * 显示用户地址
	 */
	private void displayUserAddress() {
		List<AddressInfo> addressInfos = userinfo.getAddr();
		if (addressInfos != null && addressInfos.size() > 0) {
			adapter.clear();
			adapter.addAll(addressInfos);
		}
	}

	@Override
	public boolean onItemLongClick(AdapterView<?> parent, View view,
			int position, long id) {
		showDeleteDialog(String.valueOf(position), "Delete the address item ?");
		return false;
	}

	/**
	 * 
	 * @param tag
	 * @param deleteTips
	 */
	private void showDeleteDialog(String tag, String deleteTips) {
		DeleteDialogFragment deleteDialogFragment = DeleteDialogFragment
				.newInstance(tag, deleteTips);
		deleteDialogFragment.show(getFragmentManager(), "DeleteDialogFragment");
		deleteDialogFragment.setDeleteListener(new DeleteListener() {

			@Override
			public void delete(String tag) {
				int position = Integer.parseInt(tag);
				adapter.remove(position);
				adapter.notifyDataSetChanged();
				userinfo.getAddr().remove(position);
			}
		});

	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.iv_userinfo_back:// 返回按钮
			finish();
			break;
		case R.id.btn_userinfo_head:// 更换头像
			// TODO: 没接口，先不做
			break;
		case R.id.btn_userinfo_name:// 填写姓名
			InputDialogData nameDialogData = new InputDialogData();
			nameDialogData.setTitle("INPUT NAME");
			nameDialogData.setTips("Input your name : ");
			nameDialogData.setData(userinfo.getName());
			showInputDialog(REQUEST_CODE_INPUT_NAME, nameDialogData);
			break;
		case R.id.btn_userinfo_phone:// 填写手机号
			InputDialogData phoneDialogData = new InputDialogData();
			phoneDialogData.setTitle("INPUT PHONE");
			phoneDialogData.setTips("Input your phone : ");
			phoneDialogData.setData(userinfo.getPhone());
			showInputDialog(REQUEST_CODE_INPUT_PHONE, phoneDialogData);
			break;
		case R.id.btn_userinfo_address:// 添加送餐地址
			InputDialogData AddrDialogData = new InputDialogData();
			AddrDialogData.setTitle("INPUT ADDRESS");
			AddrDialogData.setTips("Input your new address : ");
			AddrDialogData.setData("");
			showInputDialog(REQUEST_CODE_INPUT_ADDRESS, AddrDialogData);
			break;
		}
	}

	private void showInputDialog(int requestCode, InputDialogData dialogData) {

		InputDialogFragment inputDialogFragment = InputDialogFragment
				.newInstance(requestCode, dialogData);
		inputDialogFragment.setDataChangedListener(this);
		inputDialogFragment.show(getFragmentManager(), "InputDialogFragment");

	}

	@Override
	public void inputChanged(int requestCode, InputDialogData newData) {
		if (requestCode == REQUEST_CODE_INPUT_NAME) {

			String name = newData.getData();
			if (!TextUtils.isEmpty(name)) {
				userinfo.setName(name);
				displayUserName();
			}

		} else if (requestCode == REQUEST_CODE_INPUT_PHONE) {

			String phone = newData.getData();
			if (!TextUtils.isEmpty(phone)) {
				userinfo.setPhone(phone);
				displayUserPhone();
			}

		} else if (requestCode == REQUEST_CODE_INPUT_ADDRESS) {

			String address = newData.getData();
			if (!TextUtils.isEmpty(address)) {
				AddressInfo addressInfo = new AddressInfo();
				addressInfo.setAddress(address);
				userinfo.getAddr().add(addressInfo);
				displayUserAddress();
			}

		} else if (requestCode == REQUEST_CODE_DELETE_ADDRESS) {

		}

	}

	@Override
	protected void onStop() {
		super.onStop();

		Public.saveUserInfoToLocal();

	}

}
