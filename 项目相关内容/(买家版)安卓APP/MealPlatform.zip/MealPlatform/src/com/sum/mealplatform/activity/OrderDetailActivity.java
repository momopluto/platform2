package com.sum.mealplatform.activity;

import java.lang.ref.WeakReference;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ListView;
import android.widget.TextView;

import com.google.gson.reflect.TypeToken;
import com.joanzapata.android.BaseAdapterHelper;
import com.joanzapata.android.QuickAdapter;
import com.sum.mealplatform.AppContext;
import com.sum.mealplatform.R;
import com.sum.mealplatform.bean.OrderDetailInfo;
import com.sum.mealplatform.bean.OrderMenuItem;
import com.sum.mealplatform.bean.Result;
import com.sum.mealplatform.data.Public;
import com.sum.mealplatform.data.UrlConstants;
import com.sum.mealplatform.util.HttpUtil;
import com.sum.mealplatform.util.MyLog;
import com.sum.mealplatform.util.MyToast;
import com.sum.mealplatform.util.NetUtil;

public class OrderDetailActivity extends Activity implements OnClickListener {

	private String guid;

	private OrderDetailInfo orderDetail;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.order_detail_activity);
		getWindow().setBackgroundDrawable(null);

		Intent intent = getIntent();
		Bundle bundle = intent.getExtras();
		if (bundle != null) {
			guid = bundle.getString("guid");
		}

		if (!TextUtils.isEmpty(guid)) {
			getOrderDetailFromNet();
		}

		initView();

	}

	private void getOrderDetailFromNet() {
		if (!NetUtil.isConnected(AppContext.getInstance())) {
			MyToast.showShort(AppContext.getInstance(), "网络没有连接哦！");
			return;
		}

		String params = "guid=" + guid;
		HttpUtil.doPostAsyn(UrlConstants.ORDER_DETAIL_URL, params,
				new HttpUtil.CallBack() {

					@Override
					public void onRequestComplete(String json) {

						if (TextUtils.isEmpty(json)) {
							return;
						}
						
						MyLog.e(""+json);

						Result<OrderDetailInfo> result = Public
								.getGson()
								.fromJson(
										json,
										new TypeToken<Result<OrderDetailInfo>>() {
										}.getType());

						if (null == result) {
							return;
						}

						Message msg = mHandler.obtainMessage(0x155);
						Bundle bundle = new Bundle();
						bundle.putSerializable("order_detail", result.getData());
						msg.setData(bundle);
						mHandler.sendMessage(msg);

					}
				});

	}

	private MyHandler mHandler = new MyHandler(this);

	private static class MyHandler extends Handler {
		WeakReference<Activity> activityReference;

		public MyHandler(Activity activity) {
			activityReference = new WeakReference<Activity>(activity);
		}

		@Override
		public void handleMessage(Message msg) {

			final OrderDetailActivity activity = (OrderDetailActivity) activityReference
					.get();
			if (activity == null) {
				return;
			}

			if (msg.what == 0x155) {

				Bundle bundle = msg.getData();
				if (bundle == null) {
					return;
				}
				activity.orderDetail = (OrderDetailInfo) bundle
						.getSerializable("order_detail");
				activity.updateView();
			}

		}
	}

	private TextView titalRstNameTextView;
	private TextView statusTextView;
	private TextView statusTipTextView;
	private TextView rstNameTextView;
	private TextView rstPhoneTextView;
	private TextView totalCountTextView;
	private TextView totalpaymentTextView;

	private ListView listView;
	private QuickAdapter<OrderMenuItem> adapter;

	private TextView guidTextView;
	private TextView usernameTextView;
	private TextView userphoneTextView;
	private TextView useraddrTextView;
	private TextView ctimeTextView;
	private TextView deliverTimeTextView;
	private TextView noteTextView;

	private void initView() {

		findViewById(R.id.iv_myorder_detail_back).setOnClickListener(this);
		titalRstNameTextView = (TextView) findViewById(R.id.tv_myorder_restaurant_name);
		statusTextView = (TextView) findViewById(R.id.tv_myorder_menu_status);
		statusTipTextView = (TextView) findViewById(R.id.tv_myorder_status_tip);
		rstNameTextView = (TextView) findViewById(R.id.tv_myorder_rst_name);
		rstPhoneTextView = (TextView) findViewById(R.id.tv_myorder_rst_phone);
		totalCountTextView = (TextView) findViewById(R.id.tv_myorder_total_count);
		totalpaymentTextView = (TextView) findViewById(R.id.tv_myorder_total_payment);

		listView = (ListView) findViewById(R.id.list_myorder_menus);
		adapter = new QuickAdapter<OrderMenuItem>(this,
				R.layout.myorder_deail_menu_item, null) {

			@Override
			protected void convert(BaseAdapterHelper helper, OrderMenuItem item) {
				helper.setText(R.id.tv_myorder_item_menu_name, item.getName());
				helper.setText(R.id.tv_myorder_item_menu_count,
						"X" + item.getCount());
				helper.setText(R.id.tv_myorder_item_menu_price,
						"￥" + item.getPrice());

			}
		};
		listView.setAdapter(adapter);

		guidTextView = (TextView) findViewById(R.id.tv_myorder_guid);
		usernameTextView = (TextView) findViewById(R.id.tv_myorder_user_name);
		userphoneTextView = (TextView) findViewById(R.id.tv_myorder_user_phone);
		useraddrTextView = (TextView) findViewById(R.id.tv_myorder_user_addr);
		ctimeTextView = (TextView) findViewById(R.id.tv_myorder_myorder_time);
		deliverTimeTextView = (TextView) findViewById(R.id.tv_myorder_deliver_time);
		noteTextView = (TextView) findViewById(R.id.tv_myorder_note);

	}

	public void updateView() {
		if (orderDetail == null) {
			return;
		}

		MyLog.e("order detail .....");

		titalRstNameTextView.setText(orderDetail.getR_name());
		int status = orderDetail.getStatus();
		if (status == 0) {
			statusTextView.setText("订单已完成");
			statusTipTextView.setText("订单超过3小时自动完成");
		} else if (status == 1) {
			statusTextView.setText("订单未被确认，请等待");
		} else {
			statusTextView.setText("订单无效");
		}
		rstNameTextView.setText(orderDetail.getR_name());
		rstPhoneTextView.setText(orderDetail.getR_phone());
		totalCountTextView.setText("X" + orderDetail.getItem_count());
		totalpaymentTextView.setText("￥" + orderDetail.getTotal());

		adapter.addAll(orderDetail.getItem());
		adapter.notifyDataSetChanged();

		guidTextView.setText(orderDetail.getGuid());
		usernameTextView.setText(orderDetail.getC_name());
		userphoneTextView.setText(orderDetail.getC_phone());
		useraddrTextView.setText(orderDetail.getC_address());
		ctimeTextView.setText(orderDetail.getcTime());
		deliverTimeTextView.setText(orderDetail.getDeliverTime());
		noteTextView.setText(orderDetail.getNote());

	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.iv_myorder_detail_back:
			finish();
			break;

		default:
			break;
		}

	}

}
