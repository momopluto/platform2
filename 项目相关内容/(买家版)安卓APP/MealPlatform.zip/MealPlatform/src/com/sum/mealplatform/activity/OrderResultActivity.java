package com.sum.mealplatform.activity;

import com.sum.mealplatform.R;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;

public class OrderResultActivity extends Activity implements OnClickListener {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		Intent intent = getIntent();
		Bundle bundle = intent.getExtras();
		if (bundle != null) {
			String result = bundle.getString("ORDER_RESULT");
			if (result.equals("success")) {
				initOrderSuccess();
			} else {
				initOrderFailed();
			}
		}

	}

	private void initOrderFailed() {
		setContentView(R.layout.order_result_activity_fialed);
		findViewById(R.id.btn_order_result_menu).setOnClickListener(this);
	}

	private void initOrderSuccess() {
		setContentView(R.layout.order_result_activity_success);
		findViewById(R.id.btn_order_result_myorder).setOnClickListener(this);
		findViewById(R.id.btn_order_result_menu).setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {

		switch (v.getId()) {
		case R.id.btn_order_result_myorder:

			Intent intent = new Intent(OrderResultActivity.this,
					MainActivity.class);
			/**
			 * 不清楚为什么传过去的bundle为null？？？
			 */
//			Bundle bundle = new Bundle();
//			bundle.putString("isOpenMyOrder",
//					MainActivity.MESSAGE_OPEN_MY_ORDER);
//			intent.putExtras(bundle);
			MainActivity.isOpenMyOrder = true;
			startActivity(intent);

			finish();
			break;
		case R.id.btn_order_result_menu:

			finish();
			break;
		}

	}

	@Override
	public void finish() {
		setResult(RESULT_OK);
		super.finish();
	}

}
