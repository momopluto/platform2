package com.sum.mealplatform.dialog;

import android.app.DialogFragment;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.EditText;
import android.widget.TextView;

import com.sum.mealplatform.R;

public class InputDialogFragment extends DialogFragment implements
		OnClickListener {

	private static final String ARGUMENT_REQUEST_CODE = "request_code";
	private static final String ARGUMENT_TITLE = "title";
	private static final String ARGUMENT_TIPS = "tips";
	private static final String ARGUMENT_TEXT = "text";
	private int requestCode;
	private String title;
	private String tips;
	private String text;

	TextView titleTextView;
	TextView tipsTextView;
	EditText inputEditText;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		Bundle bundle = getArguments();
		if (bundle != null) {
			requestCode = bundle.getInt(ARGUMENT_REQUEST_CODE);
			title = bundle.getString(ARGUMENT_TITLE);
			tips = bundle.getString(ARGUMENT_TIPS);
			text = bundle.getString(ARGUMENT_TEXT);
		}
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		getDialog().requestWindowFeature(Window.FEATURE_NO_TITLE);

		View rootView = inflater.inflate(R.layout.dialog_input, container);

		titleTextView = (TextView) rootView
				.findViewById(R.id.tv_dialog_input_title);
		if (!TextUtils.isEmpty(title)) {
			titleTextView.setText(title);
		}

		tipsTextView = (TextView) rootView
				.findViewById(R.id.tv_dialog_input_tips);
		if (!TextUtils.isEmpty(tips)) {
			tipsTextView.setText(tips);
		}

		inputEditText = (EditText) rootView.findViewById(R.id.et_dialog_input);
		if (!TextUtils.isEmpty(text)) {
			inputEditText.setText(text);
		}

		rootView.findViewById(R.id.btn_dialog_input_cancel).setOnClickListener(
				this);
		rootView.findViewById(R.id.btn_dialog_input_save).setOnClickListener(
				this);

		return rootView;
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.btn_dialog_input_cancel:
			dismiss();
			break;
		case R.id.btn_dialog_input_save:
			if (dataChangedListener != null) {

				InputDialogData newData = new InputDialogData();
				newData.setTitle(titleTextView.getText().toString());
				newData.setTips(tipsTextView.getText().toString());
				newData.setData(inputEditText.getText().toString());

				dataChangedListener.inputChanged(requestCode, newData);
			}
			dismiss();
			break;
		}

	}

	public interface DataChangedListener {
		public void inputChanged(int requestCode, InputDialogData newData);
	}

	private DataChangedListener dataChangedListener;

	public void setDataChangedListener(DataChangedListener listener) {
		dataChangedListener = listener;
	}

	public static InputDialogFragment newInstance(int requestCode,
			InputDialogData data) {

		InputDialogFragment fragment = new InputDialogFragment();
		Bundle bundle = new Bundle();
		bundle.putInt(ARGUMENT_REQUEST_CODE, requestCode);
		bundle.putString(ARGUMENT_TITLE, data.getTitle());
		bundle.putString(ARGUMENT_TIPS, data.getTips());
		bundle.putString(ARGUMENT_TEXT, data.getData());

		fragment.setArguments(bundle);

		return fragment;
	}

}
