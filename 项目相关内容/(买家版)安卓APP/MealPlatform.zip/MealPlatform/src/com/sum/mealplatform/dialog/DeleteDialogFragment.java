package com.sum.mealplatform.dialog;

import com.sum.mealplatform.R;

import android.app.DialogFragment;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.TextView;

public class DeleteDialogFragment extends DialogFragment implements
		OnClickListener {

	private static final String ARGUMENT_TAG = "tag";
	private static final String ARGUMENT_TIPS = "tips";
	private String tag;
	private String tips;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		Bundle bundle = getArguments();
		if (bundle != null) {
			tag = bundle.getString(ARGUMENT_TAG);
			tips = bundle.getString(ARGUMENT_TIPS);
		}
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		getDialog().requestWindowFeature(Window.FEATURE_NO_TITLE);

		View rootView = inflater.inflate(R.layout.dialog_delete, container);

		if (!TextUtils.isEmpty(tips)) {
			TextView tipsTextView = (TextView) rootView
					.findViewById(R.id.tv_dialog_delete_tips);
			tipsTextView.setText(tips);
		}

		rootView.findViewById(R.id.btn_dialog_delete_cancel)
				.setOnClickListener(this);
		rootView.findViewById(R.id.btn_dialog_delete_ok).setOnClickListener(
				this);

		return rootView;
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.btn_dialog_delete_cancel:
			dismiss();
			break;
		case R.id.btn_dialog_delete_ok:
			if (deleteListener != null) {
				deleteListener.delete(tag);
			}
			dismiss();
			break;
		}

	}

	/**
	 * 
	 */
	public interface DeleteListener {
		public void delete(String tag);
	}

	private DeleteListener deleteListener;

	public void setDeleteListener(DeleteListener listener) {
		deleteListener = listener;
	}

	/**
	 * new instance
	 * 
	 * @param <T>
	 */
	public static DeleteDialogFragment newInstance(String tag, String deleteTips) {

		DeleteDialogFragment fragment = new DeleteDialogFragment();
		Bundle bundle = new Bundle();
		bundle.putString(ARGUMENT_TAG, tag);
		bundle.putString(ARGUMENT_TIPS, deleteTips);
		fragment.setArguments(bundle);

		return fragment;
	}

}
