package com.sum.mealplatform.bean;

import java.util.List;

public class RestaurantListInfo {

	private List<RestaurantInfo> open_rsts;
	private List<RestaurantInfo> close_rsts;

	public List<RestaurantInfo> getOpen_rsts() {
		return open_rsts;
	}

	public void setOpen_rsts(List<RestaurantInfo> open_rsts) {
		this.open_rsts = open_rsts;
	}

	public List<RestaurantInfo> getClose_rsts() {
		return close_rsts;
	}

	public void setClose_rsts(List<RestaurantInfo> close_rsts) {
		this.close_rsts = close_rsts;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("RestaurantTwoListInfo ");
		builder.append("[");
		builder.append("open_rsts=" + open_rsts);
		builder.append(", close_rsts=" + close_rsts);
		builder.append("]");
		return builder.toString();
	}

}
