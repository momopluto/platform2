package com.sum.mealplatform.fragment;

import java.lang.ref.WeakReference;
import java.util.List;

import android.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;

import com.google.gson.reflect.TypeToken;
import com.joanzapata.android.BaseAdapterHelper;
import com.joanzapata.android.QuickAdapter;
import com.sum.mealplatform.AppContext;
import com.sum.mealplatform.R;
import com.sum.mealplatform.activity.OrderDetailActivity;
import com.sum.mealplatform.bean.HistoryOrderInfo;
import com.sum.mealplatform.bean.RestaurantInfo;
import com.sum.mealplatform.bean.RestaurantListInfo;
import com.sum.mealplatform.bean.Result;
import com.sum.mealplatform.data.Public;
import com.sum.mealplatform.data.UrlConstants;
import com.sum.mealplatform.fragment.RestaurantListFragment.MyHandler;
import com.sum.mealplatform.helper.SerializableList;
import com.sum.mealplatform.util.HttpUtil;
import com.sum.mealplatform.util.MyLog;
import com.sum.mealplatform.util.MyToast;
import com.sum.mealplatform.util.NetUtil;

public class MyOrderFragment extends Fragment implements OnItemClickListener {

	private ListView listView;
	private QuickAdapter<HistoryOrderInfo> adapter;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {

		View rootView = inflater.inflate(R.layout.main_myorder, container,
				false);

		initView(rootView);

		getDataFromNet();

		return rootView;
	}

	private void initView(View rootView) {

		listView = (ListView) rootView.findViewById(R.id.list_myorder);
		adapter = new QuickAdapter<HistoryOrderInfo>(getActivity(),
				R.layout.main_myorder_item, null) {

			@Override
			protected void convert(BaseAdapterHelper helper,
					HistoryOrderInfo item) {
				helper.setText(R.id.tv_myorder_item_rst_name, item.getR_name());
				helper.setText(R.id.tv_myorder_item_rst_ctime, item.getcTime());
				helper.setText(R.id.tv_myorder_item_rst_payment,
						item.getTotal() + "");
				int status = item.getStatus();
				if (status == 0) {
					helper.setText(R.id.tv_myorder_item_rst_status, "订单未确认");
				} else if (status == 1) {
					helper.setText(R.id.tv_myorder_item_rst_status, "订单已确认");
				} else if (status == 3) {
					helper.setText(R.id.tv_myorder_item_rst_status, "订单无效");
				}

			}
		};
		listView.setAdapter(adapter);
		listView.setOnItemClickListener(this);

	}

	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position,
			long id) {
		MyLog.e("position = " + position);

		String guid = adapter.getItem(position).getGuid();
		MyLog.e("guid = " + guid);

		Intent intent = new Intent(getActivity(), OrderDetailActivity.class);
		Bundle bundle = new Bundle();
		bundle.putString("guid", guid);
		intent.putExtras(bundle);
		startActivity(intent);
	}

	private void getDataFromNet() {
		if (!NetUtil.isConnected(AppContext.getInstance())) {
			MyToast.showShort(AppContext.getInstance(), "网络没有连接哦！");
			return;
		}

		int client_ID = Public.userInfo.getClient_ID();
		if (client_ID == 0) {
			MyToast.showShort(AppContext.getInstance(), "请先登录");
			return;
		}

		String params = "client_ID=" + client_ID;
		HttpUtil.doPostAsyn(UrlConstants.MY_ORDERS_URL, params,
				new HttpUtil.CallBack() {

					@Override
					public void onRequestComplete(String json) {

						if (TextUtils.isEmpty(json)) {
							return;
						}

						MyLog.e("get my orders from net....");

						Result<List<HistoryOrderInfo>> result = Public
								.getGson()
								.fromJson(
										json,
										new TypeToken<Result<List<HistoryOrderInfo>>>() {
										}.getType());
						if (null == result) {
							return;
						}
						List<HistoryOrderInfo> datas = result.getData();

						if (datas == null || datas.size() == 0) {
							return;
						}

						SerializableList<HistoryOrderInfo> list = new SerializableList<HistoryOrderInfo>();
						list.setList(datas);

						Message msg = mHandler.obtainMessage(0x55);
						Bundle bundle = new Bundle();
						bundle.putSerializable("list", list);
						msg.setData(bundle);
						mHandler.sendMessage(msg);

					}
				});

	}

	/*
	 * 
	 */
	private MyHandler mHandler = new MyHandler(this);

	/**
	 *  
	 */
	static class MyHandler extends Handler {
		WeakReference<Fragment> mFragmentReference;

		MyHandler(Fragment fragment) {
			mFragmentReference = new WeakReference<Fragment>(fragment);
		}

		@Override
		public void handleMessage(Message msg) {
			if (msg.what == 0x55) {
				final MyOrderFragment fragment = (MyOrderFragment) mFragmentReference
						.get();
				if (fragment == null) {
					return;
				}

				// update data
				Bundle bundle = msg.getData();
				if (bundle != null) {
					@SuppressWarnings("unchecked")
					SerializableList<HistoryOrderInfo> list = (SerializableList<HistoryOrderInfo>) bundle
							.getSerializable("list");
					List<HistoryOrderInfo> newData = list.getList();

					int i = 0;
					while (i < newData.size()) {
						boolean changed = false;
						int oldDataSize = fragment.adapter.getCount();
						for (int j = 0; j < oldDataSize; j++) {
							if (newData.get(i).getR_ID() == fragment.adapter
									.getItem(j).getR_ID()) {
								newData.remove(i);
								changed = true;
								break;
							}
						}
						if (!changed) {
							i++;
						}
					}

					if (newData != null && newData.size() > 0) {
						fragment.adapter.addAll(newData);
					} else {
						MyToast.showShort(AppContext.getInstance(), "没有更多的订单啦！");
					}
				}

			}
		}
	}
}
