package com.sum.mealplatform.bean;

public class AddressInfo {

	private int address_ID;
	private String address;

	public int getAddress_ID() {
		return address_ID;
	}

	public void setAddress_ID(int address_ID) {
		this.address_ID = address_ID;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("{\"address_ID\"=\"");
		builder.append(address_ID);
		builder.append("\",\"address\"=\"");
		builder.append(address);
		builder.append("\"}");
		return builder.toString();
	}

}
