package com.sum.mealplatform.activity;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.util.SparseArray;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.google.gson.reflect.TypeToken;
import com.joanzapata.android.BaseAdapterHelper;
import com.joanzapata.android.QuickAdapter;
import com.sum.mealplatform.AppContext;
import com.sum.mealplatform.R;
import com.sum.mealplatform.bean.MenuInfo;
import com.sum.mealplatform.bean.OrderInfo;
import com.sum.mealplatform.bean.OrderMenuItem;
import com.sum.mealplatform.bean.RestaurantInfo;
import com.sum.mealplatform.bean.Result;
import com.sum.mealplatform.data.Public;
import com.sum.mealplatform.data.UrlConstants;
import com.sum.mealplatform.helper.SerializableList;
import com.sum.mealplatform.util.HttpUtil;
import com.sum.mealplatform.util.MyToast;
import com.sum.mealplatform.util.NetUtil;
import com.sum.mealplatform.view.SwipeRefreshLayout;

public class MenuActivity extends Activity implements OnClickListener {

	private static final int REQUEST_CODE_MEAL_CAR = 0x12;

	private SwipeRefreshLayout swipeRefreshLayout;
	private ListView listview;
	private QuickAdapter<MenuInfo> adapter;

	private int crrRestaurantId;
	private String crrRestaurantName;
	private int crrRestautantDeliverPrice;

	private TextView selectedPriceTextView;
	private TextView deliverPriceTextView;
	private Button submitOrderButton;

	private OrderInfo orderInfo;

	private SparseArray<OrderMenuItem> selectedMenuItems = new SparseArray<OrderMenuItem>();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.menu_activity);
		getWindow().setBackgroundDrawable(null);

		// 获取参数
		Intent intent = getIntent();
		Bundle bundle = intent.getBundleExtra("ARGUMENTS");
		crrRestaurantId = bundle.getInt("RESTAURANT_ID");
		crrRestaurantName = bundle.getString("RESTAURANT_NAME");
		crrRestautantDeliverPrice = bundle.getInt("RESTAURANT_AGENT_FEE");

		initView();
		initOrderInfo();

	}

	private void initOrderInfo() {
		orderInfo = new OrderInfo();
		orderInfo.setR_ID(crrRestaurantId);
		orderInfo.setItem(new ArrayList<OrderMenuItem>());
	}

	private void initView() {
		/*
		 * 返回键
		 */
		findViewById(R.id.iv_menu_back).setOnClickListener(
				new OnClickListener() {

					@Override
					public void onClick(View v) {
						finish();
					}
				});

		/*
		 * 餐厅名
		 */
		TextView textView = (TextView) findViewById(R.id.tv_menu_restaurant_name);
		textView.setText(crrRestaurantName);

		/*
		 * 购物车
		 */
		selectedPriceTextView = (TextView) findViewById(R.id.tv_menu_selected_price);
		deliverPriceTextView = (TextView) findViewById(R.id.tv_menu_deliver_price);
		deliverPriceTextView.setText("￥" + crrRestautantDeliverPrice + " 元起送");
		submitOrderButton = (Button) findViewById(R.id.btn_menu_submit_order);
		submitOrderButton.setOnClickListener(this);

		/*
		 * SwipeRefreshLayout
		 */
		swipeRefreshLayout = (SwipeRefreshLayout) findViewById(R.id.swiperefresh_menu);
		swipeRefreshLayout
				.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
					@Override
					public void onRefresh() {
						// 更新操作
						myUpdateOperation();
					}
				});
		/*
		 * 内容列表
		 */
		listview = (ListView) findViewById(R.id.listview_menu);
		adapter = new QuickAdapter<MenuInfo>(this, R.layout.menu_item, null) {

			@Override
			protected void convert(BaseAdapterHelper helper, MenuInfo item) {
				helper.setText(R.id.tv_menu_name, item.getName());
				helper.setText(R.id.tv_menu_month_sales,
						"" + item.getMonth_sales());

				int position = helper.getPosition();

				helper.setTag(R.id.tv_menu_price, position);
				helper.setText(R.id.tv_menu_price, "¥" + item.getPrice());
				helper.setOnClickListener(R.id.tv_menu_price, MenuActivity.this);

				helper.setTag(R.id.tv_menu_reduce_count, position);
				helper.setOnClickListener(R.id.tv_menu_reduce_count,
						MenuActivity.this);

				OrderMenuItem orderMenuItem = selectedMenuItems.get(position);
				if (orderMenuItem == null) {
					helper.setVisibility(R.id.tv_menu_count, View.INVISIBLE);
					helper.setVisibility(R.id.tv_menu_reduce_count,
							View.INVISIBLE);
				} else {
					helper.setText(R.id.tv_menu_count,
							"" + orderMenuItem.getCount());
					helper.setVisibility(R.id.tv_menu_count, View.VISIBLE);
					helper.setVisibility(R.id.tv_menu_reduce_count,
							View.VISIBLE);
				}
			}

		};
		listview.setAdapter(adapter);

		// 强制启动刷新
		swipeRefreshLayout.startLoadingAnimForRefresh();
	}

	/**
	 * 加载/更新操作
	 */
	private void myUpdateOperation() {
		if (!NetUtil.isConnected(AppContext.getInstance())) {
			swipeRefreshLayout.setRefreshing(false);
			MyToast.showShort(AppContext.getInstance(), "网络没有连接哦！");
			return;
		}

		String params = "r_ID=" + crrRestaurantId * 10086;
		HttpUtil.doPostAsyn(UrlConstants.MENU_URL, params,
				new HttpUtil.CallBack() {

					@Override
					public void onRequestComplete(String result) {

						if (TextUtils.isEmpty(result)) {
							return;
						}

						List<MenuInfo> datas = resultToMenuInfoList(result);
						if (null == datas) {
							return;
						}

						SerializableList<MenuInfo> list = new SerializableList<MenuInfo>();
						list.setList(datas);
						Message msg = mHandler.obtainMessage(0x124);
						Bundle bundle = new Bundle();
						bundle.putSerializable("list", list);
						msg.setData(bundle);
						mHandler.sendMessage(msg);

					}
				});
	}

	private static List<MenuInfo> resultToMenuInfoList(String json) {

		Result<List<MenuInfo>> result = Public.getGson().fromJson(json,
				new TypeToken<Result<List<MenuInfo>>>() {
				}.getType());

		return result.getData();
	}

	/*
	 * 
	 */
	private MyHandler mHandler = new MyHandler(this);

	private static class MyHandler extends Handler {
		WeakReference<Activity> activityReference;

		public MyHandler(Activity activity) {
			activityReference = new WeakReference<Activity>(activity);
		}

		@Override
		public void handleMessage(Message msg) {

			final MenuActivity activity = (MenuActivity) activityReference
					.get();
			if (activity == null) {
				return;
			}

			if (msg.what == 0x124) {

				Bundle bundle = msg.getData();
				if (bundle == null) {
					activity.swipeRefreshLayout.setRefreshing(false);
					return;
				}

				@SuppressWarnings("unchecked")
				SerializableList<MenuInfo> list = (SerializableList<MenuInfo>) bundle
						.getSerializable("list");
				List<MenuInfo> newData = list.getList();
				int i = 0;
				while (i < newData.size()) {
					boolean changed = false;
					int oldDataSize = activity.adapter.getCount();
					for (int j = 0; j < oldDataSize; j++) {
						if (newData.get(i).getMenu_ID() == activity.adapter
								.getItem(j).getMenu_ID()) {
							newData.remove(i);
							changed = true;
							break;
						}
					}
					if (!changed) {
						i++;
					}
				}

				if (newData != null && newData.size() > 0) {
					activity.adapter.addAll(newData);
				} else {
					MyToast.showShort(AppContext.getInstance(), "没有更多的餐厅啦！");
				}

				activity.swipeRefreshLayout.setRefreshing(false);

			} else if (msg.what == 0x126) {

				Bundle dataBundle = msg.getData();
				long resultCode = dataBundle.getLong("RESULT_CODE");
				if (resultCode == 1 || resultCode == 0) {
				} else {
					MyToast.showShort(AppContext.getInstance(),
							"不好意思，餐厅已不在营业时间啦！");
				}

			}
		}
	}

	@Override
	public void onClick(View v) {

		if (v.getId() == R.id.tv_menu_price) {

			int position = (int) v.getTag();
			addSelectedMenuItems(position);

			updateShoppingCarPrice();

		} else if (v.getId() == R.id.tv_menu_reduce_count) {

			int position = (int) v.getTag();
			reduceSelectedMenuItems(position);

			updateShoppingCarPrice();

		} else if (v.getId() == R.id.btn_menu_submit_order) {
			checkIsRestaurantOpen();
			Intent intent = new Intent(this, MealCarActivity.class);
			Bundle extraBundle = new Bundle();
			extraBundle.putSerializable("ORDER_INFO", orderInfo);
			intent.putExtra("BUNDLE", extraBundle);
			startActivityForResult(intent, REQUEST_CODE_MEAL_CAR);
		}

	}

	private void checkIsRestaurantOpen() {
		if (!NetUtil.isConnected(AppContext.getInstance())) {
			MyToast.showShort(AppContext.getInstance(), "网络没有连接哦！");
			return;
		}

		String params = "r_ID=" + crrRestaurantId;
		HttpUtil.doPostAsyn(UrlConstants.RESTAURANT_STATUS_URL, params,
				new HttpUtil.CallBack() {

					@Override
					public void onRequestComplete(String json) {

						if (TextUtils.isEmpty(json)) {
							return;
						}
						Result<RestaurantInfo> result = Public
								.getGson()
								.fromJson(
										json,
										new TypeToken<Result<RestaurantInfo>>() {
										}.getType());

						long errCode = result.getErrcode();
						if (errCode == 0) {
							long resultCode = result.getResult();
							Message msg = mHandler.obtainMessage(0x126);
							Bundle bundle = new Bundle();
							bundle.putLong("RESULT_CODE", resultCode);
							msg.setData(bundle);
							mHandler.sendMessage(msg);
						}
					}
				});

	}

	private void addSelectedMenuItems(int position) {

		MenuInfo menuInfo = adapter.getItem(position);
		int addMenuCount = 1;

		List<OrderMenuItem> list = orderInfo.getItem();
		int size = list.size();
		boolean isFound = false;
		OrderMenuItem item = null;
		for (int i = 0; i < size; i++) {
			item = list.get(i);
			if (item.getEntity_id() == menuInfo.getMenu_ID()) {

				int crrMenuCount = item.getCount();
				int targetMenuCount = crrMenuCount + addMenuCount;
				item.setCount(targetMenuCount);
				item.setTotal(targetMenuCount * item.getPrice());

				int crrOrderTotal = orderInfo.getTotal();
				orderInfo.setTotal(crrOrderTotal + item.getPrice());

				isFound = true;
				break;
			}
		}
		if (!isFound) {
			item = new OrderMenuItem();
			item.setEntity_id(menuInfo.getMenu_ID());
			item.setName(menuInfo.getName());
			item.setPrice(menuInfo.getPrice());
			item.setCount(1);
			item.setTotal(menuInfo.getPrice());
			list.add(item);

			int crrOrderTotal = orderInfo.getTotal();
			orderInfo.setTotal(crrOrderTotal + menuInfo.getPrice());
		}

		selectedMenuItems.put(position, item);

		adapter.notifyDataSetChanged();

	}

	private void reduceSelectedMenuItems(int position) {

		MenuInfo menuInfo = adapter.getItem(position);
		int reduceMenuCount = 1;

		List<OrderMenuItem> list = orderInfo.getItem();
		int size = list.size();
		OrderMenuItem item = null;
		for (int i = 0; i < size; i++) {
			item = list.get(i);
			if (item.getEntity_id() == menuInfo.getMenu_ID()) {

				int crrMenuCount = item.getCount();
				int targetMenuCount = crrMenuCount - reduceMenuCount;
				item.setCount(targetMenuCount);
				item.setTotal(targetMenuCount * item.getPrice());

				int crrOrderTotal = orderInfo.getTotal();
				orderInfo.setTotal(crrOrderTotal - item.getPrice());

				if (targetMenuCount == 0) {
					list.remove(i);
					selectedMenuItems.remove(position);
				}

				break;
			}
		}

		adapter.notifyDataSetChanged();
	}

	private void updateShoppingCarPrice() {
		selectedPriceTextView.setText("￥" + orderInfo.getTotal());

		int deliverPrice = crrRestautantDeliverPrice - orderInfo.getTotal();
		if (deliverPrice > 0) {
			deliverPriceTextView.setText("还差￥" + deliverPrice + " 元起送");
			if (deliverPriceTextView.getVisibility() == View.GONE) {
				submitOrderButton.setVisibility(View.GONE);
				deliverPriceTextView.setVisibility(View.VISIBLE);
			}
		} else {
			deliverPriceTextView.setVisibility(View.GONE);
			submitOrderButton.setVisibility(View.VISIBLE);
		}
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (requestCode == REQUEST_CODE_MEAL_CAR) {
			if (resultCode == RESULT_OK) {

			}
		}
	}

}
