package com.sum.mealplatform.activity;

import java.lang.ref.WeakReference;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.List;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;

import com.google.gson.reflect.TypeToken;
import com.sum.mealplatform.AppContext;
import com.sum.mealplatform.R;
import com.sum.mealplatform.bean.MenuInfo;
import com.sum.mealplatform.bean.OrderInfo;
import com.sum.mealplatform.bean.RestaurantInfo;
import com.sum.mealplatform.bean.Result;
import com.sum.mealplatform.bean.UserInfo;
import com.sum.mealplatform.data.Public;
import com.sum.mealplatform.data.UrlConstants;
import com.sum.mealplatform.helper.SerializableList;
import com.sum.mealplatform.util.HttpUtil;
import com.sum.mealplatform.util.MyLog;
import com.sum.mealplatform.util.MyToast;
import com.sum.mealplatform.util.NetUtil;

public class OrderActivity extends Activity implements OnClickListener {

	private static final int REQUEST_CODE_USER_INFO = 0x1;
	private static final int REQUEST_CODE_ORDER_RESULT = 0x2;

	private TextView nameTextView;
	private TextView phoneTextView;
	private TextView addressTextView;
	private TextView orderTimeTextView;
	private TextView deliverTimeTextView;
	private TextView noteTextView;

	private OrderInfo orderInfo;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.order_activity);
		getWindow().setBackgroundDrawable(null);

		getOrderInfoFromIntent();
		getOrderInfoFromUserInfo();
		setOrderInfoOrderTime();

		initView();
	}

	private void getOrderInfoFromIntent() {
		Intent intent = getIntent();
		Bundle bundle = intent.getExtras();
		orderInfo = (OrderInfo) bundle.get("ORDER_INFO");
	}

	private void getOrderInfoFromUserInfo() {
		orderInfo.setC_name(Public.userInfo.getName());
		orderInfo.setC_phone(Public.userInfo.getPhone());
		orderInfo.setC_address(Public.userInfo.getAddr().get(0).getAddress());
	}

	private void setOrderInfoOrderTime() {
		orderInfo.setcTime(getOrderTime());
	}

	@SuppressLint("SimpleDateFormat")
	private String getOrderTime() {
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date crrDate = new Date(System.currentTimeMillis());
		String orderTime = format.format(crrDate);

		return orderTime;
	}

	private void initView() {
		findViewById(R.id.iv_order_back).setOnClickListener(this);
		findViewById(R.id.btn_order_submit).setOnClickListener(this);

		nameTextView = (TextView) findViewById(R.id.tv_order_user_name);
		phoneTextView = (TextView) findViewById(R.id.tv_order_user_phone);
		addressTextView = (TextView) findViewById(R.id.tv_order_user_addr);
		orderTimeTextView = (TextView) findViewById(R.id.tv_order_order_time);
		deliverTimeTextView = (TextView) findViewById(R.id.tv_order_deliver_time);
		orderInfo.setDeliverTime(deliverTimeTextView.getText().toString());
		noteTextView = (TextView) findViewById(R.id.tv_order_note);
		orderInfo.setNote(noteTextView.getText().toString());
		showOrderInfo();

		findViewById(R.id.linear_order_uder_name).setOnClickListener(this);
		findViewById(R.id.linear_order_uder_phone).setOnClickListener(this);
		findViewById(R.id.linear_order_uder_addr).setOnClickListener(this);
		findViewById(R.id.linear_order_deliver_time).setOnClickListener(this);
		findViewById(R.id.linear_order_note).setOnClickListener(this);

	}

	private void showOrderInfo() {
		nameTextView.setText(orderInfo.getC_name());
		phoneTextView.setText(orderInfo.getC_phone());
		addressTextView.setText(orderInfo.getC_address());
		orderTimeTextView.setText(orderInfo.getcTime());
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.iv_order_back:
			finish();
			break;

		case R.id.linear_order_uder_name:
		case R.id.linear_order_uder_phone:
		case R.id.linear_order_uder_addr:
			if (!isOrderInfoAllUserInfoWritten()) {
				Intent intent = new Intent(OrderActivity.this,
						UserInfoActivity.class);
				startActivityForResult(intent, REQUEST_CODE_USER_INFO);
			}
			break;
		case R.id.linear_order_deliver_time:

			break;
		case R.id.linear_order_note:

			break;

		case R.id.btn_order_submit:
			if (isOrderInfoAllUserInfoWritten()) {
				submitOrder();
			} else {
				MyToast.showShort(AppContext.getInstance(), "用户信息还没填写完整哦！亲！");
			}
			break;
		}
	}

	private boolean isOrderInfoAllUserInfoWritten() {
		String name = orderInfo.getC_name();
		if (TextUtils.isEmpty(name)) {
			return false;
		}
		String phone = orderInfo.getC_phone();
		if (TextUtils.isEmpty(phone)) {
			return false;
		}
		String address = orderInfo.getC_address();
		if (TextUtils.isEmpty(address)) {
			return false;
		}

		return true;
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (requestCode == REQUEST_CODE_USER_INFO) {
			getOrderInfoFromUserInfo();
			showOrderInfo();
		} else if (requestCode == REQUEST_CODE_ORDER_RESULT) {
			if (resultCode == RESULT_OK) {
				setResult(RESULT_OK);
				finish();
			}
		}
	}

	private void submitOrder() {

		if (!NetUtil.isConnected(AppContext.getInstance())) {
			MyToast.showShort(AppContext.getInstance(), "网络没有连接哦！");
			return;
		}

		String params = "order="
				+ Public.getGson().toJson(orderInfo,
						new TypeToken<OrderInfo>() {
						}.getType());
		MyLog.e(params);
		HttpUtil.doPostAsyn(UrlConstants.ORDER_DONE_URL, params,
				new HttpUtil.CallBack() {

					@Override
					public void onRequestComplete(String json) {

						MyLog.e(json);

						if (TextUtils.isEmpty(json)) {
							MyToast.showShort(AppContext.getInstance(), "发生错误~");
							return;
						}

						Result<OrderInfo> result = null;

						try {
							result = Public.getGson().fromJson(json,
									new TypeToken<Result<OrderInfo>>() {
									}.getType());
						} catch (Exception e) {
						}

						if (null == result) {// error
							Message msg = mHandler.obtainMessage(0x129);
							mHandler.sendMessage(msg);
						}

						long errCode = result.getErrcode();
						if (errCode == 0) {
							Message msg = mHandler.obtainMessage(0x129);
							mHandler.sendMessage(msg);
						} else {
							Message msg = mHandler.obtainMessage(0x130);
							mHandler.sendMessage(msg);
						}

					}
				});
	}

	private MyHandler mHandler = new MyHandler(this);

	private static class MyHandler extends Handler {
		WeakReference<Activity> activityReference;

		public MyHandler(Activity activity) {
			activityReference = new WeakReference<Activity>(activity);
		}

		@Override
		public void handleMessage(Message msg) {

			final OrderActivity activity = (OrderActivity) activityReference
					.get();
			if (activity == null) {
				return;
			}

			if (msg.what == 0x129) {// success
				MyLog.e("order success");
				Intent intent = new Intent(activity, OrderResultActivity.class);
				Bundle bundle = new Bundle();
				bundle.putString("ORDER_RESULT", "success");
				intent.putExtras(bundle);
				activity.startActivityForResult(intent,
						REQUEST_CODE_ORDER_RESULT);

			} else if (msg.what == 0x130) {// error
				MyLog.e("order faild");
				Intent intent = new Intent(activity, OrderResultActivity.class);
				Bundle bundle = new Bundle();
				bundle.putString("ORDER_RESULT", "faild");
				intent.putExtras(bundle);
				activity.startActivityForResult(intent,
						REQUEST_CODE_ORDER_RESULT);

			}
		}
	}

}
