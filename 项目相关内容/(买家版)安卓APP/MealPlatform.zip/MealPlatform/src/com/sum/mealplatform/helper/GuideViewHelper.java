package com.sum.mealplatform.helper;

import java.util.ArrayList;
import java.util.List;

import com.sum.mealplatform.R;

import android.app.Activity;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;

/**
 * 启动引导界面
 * 
 */
public class GuideViewHelper {

	private Activity activity;

	private ViewPager viewPager;
	private PagerAdapter pagerAdapter;
	private List<View> guideViews = new ArrayList<View>();

	public interface CloseListener {
		public void close();
	}

	private CloseListener closeListener;

	public void registerCloseListener(CloseListener listener) {
		closeListener = listener;
	}

	public GuideViewHelper(Activity activity) {
		this.activity = activity;

		initView();
	}

	private void initView() {
		View rootView = activity.getLayoutInflater().inflate(
				R.layout.guide_view_container, null);
		activity.setContentView(rootView);

		viewPager = (ViewPager) rootView.findViewById(R.id.viewpager_guide);
		initGuideViews();
		initPagerAdapter();
		viewPager.setAdapter(pagerAdapter);
		initCallback();
	}

	private void initGuideViews() {
		View view;
		view = activity.getLayoutInflater().inflate(R.layout.guide_view_first,
				null);
		guideViews.add(view);
		view = activity.getLayoutInflater().inflate(R.layout.guide_view_second,
				null);
		guideViews.add(view);
		view = activity.getLayoutInflater().inflate(R.layout.guide_view_third,
				null);
		guideViews.add(view);
		view.findViewById(R.id.btn_guide_enter).setOnClickListener(
				new OnClickListener() {

					@Override
					public void onClick(View v) {

						if (closeListener != null) {
							closeListener.close();
						}

					}
				});
	}

	private void initPagerAdapter() {
		pagerAdapter = new PagerAdapter() {

			@Override
			public Object instantiateItem(ViewGroup container, int position) {
				container.addView(guideViews.get(position));
				return guideViews.get(position);
			}

			@Override
			public void destroyItem(ViewGroup container, int position,
					Object object) {
				container.removeView(guideViews.get(position));
			}

			@Override
			public boolean isViewFromObject(View view, Object obj) {
				return view == obj;
			}

			@Override
			public int getCount() {
				return guideViews.size();
			}
		};
	}

	private void initCallback() {
		viewPager.setOnPageChangeListener(new OnPageChangeListener() {

			@Override
			public void onPageSelected(int position) {
			}

			@Override
			public void onPageScrolled(int position, float positionOffset,
					int positionOffsetPixels) {
			}

			@Override
			public void onPageScrollStateChanged(int arg3) {
			}
		});
	}
}
