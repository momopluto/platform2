package com.sum.mealplatform.activity;

import android.app.Activity;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Intent;
import android.os.Bundle;
import android.os.Message;
import android.support.v4.widget.DrawerLayout;
import android.text.TextUtils;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;

import com.google.gson.reflect.TypeToken;
import com.sum.mealplatform.AppContext;
import com.sum.mealplatform.R;
import com.sum.mealplatform.bean.LoginCallBackInfo;
import com.sum.mealplatform.bean.OrderInfo;
import com.sum.mealplatform.bean.Result;
import com.sum.mealplatform.data.Public;
import com.sum.mealplatform.data.UrlConstants;
import com.sum.mealplatform.fragment.MyOrderFragment;
import com.sum.mealplatform.fragment.RestaurantListFragment;
import com.sum.mealplatform.helper.GuideViewHelper;
import com.sum.mealplatform.helper.GuideViewHelper.CloseListener;
import com.sum.mealplatform.util.HttpUtil;
import com.sum.mealplatform.util.MyLog;
import com.sum.mealplatform.util.MyToast;
import com.sum.mealplatform.util.NetUtil;

public class MainActivity extends Activity implements OnClickListener {

	public static final String MESSAGE_OPEN_MY_ORDER = "open_my_order";
	public static boolean isOpenMyOrder;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);

		if (Public.isFirstTimeEnter()) {
			openGrideView();
		} else {
			openStartView();
		}
	}

	private void openGrideView() {
		GuideViewHelper guideViewHelper = new GuideViewHelper(this);
		guideViewHelper.registerCloseListener(new CloseListener() {

			@Override
			public void close() {

				Public.setFirstTimeEnterToFalse();

				initialize();
			}
		});
	}

	private void openStartView() {
		// TODO: 播放启动动画

		// TODO：动画结束，初始化主界面
		initialize();
	}

	private static final int REQUEST_CODE_USERINFO = 0x123;

	private DrawerLayout drawerLayout;

	private View leftDrawer;

	public interface ShowDrawerListener {
		public void showDrawer();
	}

	private ShowDrawerListener showDrawerListener = new ShowDrawerListener() {

		@Override
		public void showDrawer() {
			drawerLayout.openDrawer(leftDrawer);
		}
	};

	private RestaurantListFragment restaurantListFragment;
	private MyOrderFragment myOrderFragment;

	/**
	 * 初始化操作（注意需要调用Activity的setContentView()方法）
	 */
	private void initialize() {
		getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
		setContentView(R.layout.main_activity);
		getWindow().setBackgroundDrawable(null);

		drawerLayout = (DrawerLayout) findViewById(R.id.main_drawer_layout);

		initLeftDrawer();

		setDefaultFragment();

	}

	@Override
	protected void onPostResume() {
		super.onPostResume();

		if (isOpenMyOrder) {
			openMyOrderFragment();
			isOpenMyOrder = false;
		}
	}

	private void openMyOrderFragment() {
		MyLog.e("open_my_order fragment");
		FragmentManager fm = getFragmentManager();
		FragmentTransaction transaction = fm.beginTransaction();
		hideFragments(transaction);
		if (null == myOrderFragment) {
			myOrderFragment = new MyOrderFragment();
			transaction.add(R.id.main_content, myOrderFragment);
		} else {
			transaction.show(myOrderFragment);
		}
		transaction.commit();

		drawerLayout.closeDrawer(leftDrawer);
	}

	private void initLeftDrawer() {
		leftDrawer = findViewById(R.id.drawer_content);
		leftDrawer.setOnTouchListener(new OnTouchListener() {

			@Override
			public boolean onTouch(View v, MotionEvent event) {
				return true;
			}
		});

		findViewById(R.id.drawer_userinfo).setOnClickListener(this);
		findViewById(R.id.tv_drawer_choose_restaurant).setOnClickListener(this);
		findViewById(R.id.tv_drawer_my_orders).setOnClickListener(this);

		// TODO: 显示用户头像（没接口，先不做）

		displayUserPhone();
	}

	private void displayUserPhone() {
		String userphone = Public.userInfo.getPhone();
		if (!TextUtils.isEmpty(userphone)) {
			TextView textView = (TextView) findViewById(R.id.tv_drawer_phone);
			textView.setText(userphone);

			getClientIdForNet();
		}
	}

	private void getClientIdForNet() {
		MyLog.e("login");
		
		if (!NetUtil.isConnected(AppContext.getInstance())) {
			MyToast.showShort(AppContext.getInstance(), "网络没有连接哦！");
			return;
		}

		String params = "phone=" + Public.userInfo.getPhone();
		HttpUtil.doPostAsyn(UrlConstants.CLIENT_LOGIN_URL, params,
				new HttpUtil.CallBack() {

					@Override
					public void onRequestComplete(String json) {

						if (TextUtils.isEmpty(json)) {
							MyToast.showShort(AppContext.getInstance(), "发生错误~");
							return;
						}
						
						MyLog.e("login call back");

						Result<LoginCallBackInfo> result = null;
						try {
							result = Public.getGson().fromJson(json,
									new TypeToken<Result<LoginCallBackInfo>>() {
									}.getType());
						} catch (Exception e) {
						}

						if (result != null) {
							Public.userInfo.setClient_ID(result.getData()
									.getClient_ID());
							MyLog.e("login call back data client_ID = "
									+ Public.userInfo.getClient_ID());
						}

					}
				});

	}

	private void setDefaultFragment() {
		FragmentManager fm = getFragmentManager();
		FragmentTransaction transaction = fm.beginTransaction();
		restaurantListFragment = new RestaurantListFragment();
		restaurantListFragment.setShowDrawerListener(showDrawerListener);
		transaction.add(R.id.main_content, restaurantListFragment);
		transaction.commit();
	}

	@Override
	public void onClick(View v) {

		if (v.getId() == R.id.drawer_userinfo) {

			Intent intent = new Intent(MainActivity.this,
					UserInfoActivity.class);
			startActivityForResult(intent, REQUEST_CODE_USERINFO);
			overridePendingTransition(R.anim.userinfo_activity_enter, 0);
			return;
		}

		FragmentManager fm = getFragmentManager();
		FragmentTransaction transaction = fm.beginTransaction();
		// 先隐藏掉所有的Fragment，以防止有多个Fragment显示在界面上的情况
		hideFragments(transaction);

		switch (v.getId()) {
		case R.id.tv_drawer_choose_restaurant:
			if (null == restaurantListFragment) {
				restaurantListFragment = new RestaurantListFragment();
				transaction.add(R.id.main_content, restaurantListFragment);
				restaurantListFragment
						.setShowDrawerListener(showDrawerListener);
			} else {
				transaction.show(restaurantListFragment);
			}
			break;
		case R.id.tv_drawer_my_orders:
			if (null == myOrderFragment) {
				myOrderFragment = new MyOrderFragment();
				transaction.add(R.id.main_content, myOrderFragment);
			} else {
				transaction.show(myOrderFragment);
			}
			break;
		}

		transaction.commit();

		drawerLayout.closeDrawer(leftDrawer);
	}

	private void hideFragments(FragmentTransaction transaction) {
		if (restaurantListFragment != null) {
			transaction.hide(restaurantListFragment);
		}
		if (myOrderFragment != null) {
			transaction.hide(myOrderFragment);
		}
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (requestCode == REQUEST_CODE_USERINFO) {
			displayUserPhone();
		}
	}
}
