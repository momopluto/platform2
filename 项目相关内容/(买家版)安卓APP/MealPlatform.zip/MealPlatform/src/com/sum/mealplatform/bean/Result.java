package com.sum.mealplatform.bean;

public class Result<T> {

	private long result;
	private long errcode;
	private String errmsg;
	private T data;

	public long getErrcode() {
		return errcode;
	}

	public void setErrcode(long errcode) {
		this.errcode = errcode;
	}

	public String getErrmsg() {
		return errmsg;
	}

	public void setErrmsg(String errmsg) {
		this.errmsg = errmsg;
	}

	public long getResult() {
		return result;
	}

	public void setResult(long result) {
		this.result = result;
	}

	public T getData() {
		return data;
	}

	public void setData(T data) {
		this.data = data;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Result ");
		builder.append("[");
		builder.append("result=" + result);
		builder.append("errcode=" + errcode);
		builder.append(", errmsg=" + errmsg);
		builder.append(", data=" + data);
		builder.append("]");
		return builder.toString();
	}

}
