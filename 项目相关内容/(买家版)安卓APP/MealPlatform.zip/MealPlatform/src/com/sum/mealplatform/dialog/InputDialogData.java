package com.sum.mealplatform.dialog;

import java.io.Serializable;

/**
 * 用于向Dialog传递指定数据
 *
 */
public class InputDialogData implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String title;
	private String tips;
	private String data;

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getTips() {
		return tips;
	}

	public void setTips(String tips) {
		this.tips = tips;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}
}