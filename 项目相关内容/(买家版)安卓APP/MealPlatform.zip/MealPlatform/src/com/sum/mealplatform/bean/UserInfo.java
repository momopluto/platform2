package com.sum.mealplatform.bean;

import java.util.List;

public class UserInfo {

	private int client_ID;
	private String name;
	private String phone;
	private List<AddressInfo> addr;

	public int getClient_ID() {
		return client_ID;
	}

	public void setClient_ID(int client_ID) {
		this.client_ID = client_ID;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public List<AddressInfo> getAddr() {
		return addr;
	}

	public void setAddr(List<AddressInfo> addr) {
		this.addr = addr;
	}

}
