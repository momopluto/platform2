package com.sum.mealplatform.bean;

/**
 * 餐厅信息类
 *
 */
public class RestaurantInfo {

	private int r_ID;
	private int home_ID;
	private String logo_url;
	private String name;
	private String address;
	private String descr;
	private String phone;
	private String promotion_info;
	private String deliver_desc;
	private int agent_fee;
	private int isOpen;
	private int is_bookable;
	private String time_1_open;
	private String time_1_close;
	private String time_2_open;
	private String time_2_close;
	private String time_3_open;
	private String time_3_close;
	private String warning_tone;
	private int admin_ID;
	private int userStatus;
	private int service_ID;
	private int serviceStatus;
	private int open_status;
	private int month_sales;
	private int last_month_sales;
	
	/*
	 * 状态标识，true代表餐厅在当前刷新时间为营业
	 */
	private boolean duringOpen;
	
	public boolean isDuringOpen() {
		return duringOpen;
	}

	public void setDuringOpen(boolean duringOpen) {
		this.duringOpen = duringOpen;
	}
	/*
	 * 
	 */

	public int getR_ID() {
		return r_ID;
	}

	public void setR_ID(int r_ID) {
		this.r_ID = r_ID;
	}

	public int getHome_ID() {
		return home_ID;
	}

	public void setHome_ID(int home_ID) {
		this.home_ID = home_ID;
	}

	public String getLogo_url() {
		return logo_url;
	}

	public void setLogo_url(String logo_url) {
		this.logo_url = logo_url;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getDescr() {
		return descr;
	}

	public void setDescr(String descr) {
		this.descr = descr;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getPromotion_info() {
		return promotion_info;
	}

	public void setPromotion_info(String promotion_info) {
		this.promotion_info = promotion_info;
	}

	public String getDeliver_desc() {
		return deliver_desc;
	}

	public void setDeliver_desc(String deliver_desc) {
		this.deliver_desc = deliver_desc;
	}

	public int getAgent_fee() {
		return agent_fee;
	}

	public void setAgent_fee(int agent_fee) {
		this.agent_fee = agent_fee;
	}

	public int getIsOpen() {
		return isOpen;
	}

	public void setIsOpen(int isOpen) {
		this.isOpen = isOpen;
	}

	public int getIs_bookable() {
		return is_bookable;
	}

	public void setIs_bookable(int is_bookable) {
		this.is_bookable = is_bookable;
	}

	public String getTime_1_open() {
		return time_1_open;
	}

	public void setTime_1_open(String time_1_open) {
		this.time_1_open = time_1_open;
	}

	public String getTime_1_close() {
		return time_1_close;
	}

	public void setTime_1_close(String time_1_close) {
		this.time_1_close = time_1_close;
	}

	public String getTime_2_open() {
		return time_2_open;
	}

	public void setTime_2_open(String time_2_open) {
		this.time_2_open = time_2_open;
	}

	public String getTime_2_close() {
		return time_2_close;
	}

	public void setTime_2_close(String time_2_close) {
		this.time_2_close = time_2_close;
	}

	public String getTime_3_open() {
		return time_3_open;
	}

	public void setTime_3_open(String time_3_open) {
		this.time_3_open = time_3_open;
	}

	public String getTime_3_close() {
		return time_3_close;
	}

	public void setTime_3_close(String time_3_close) {
		this.time_3_close = time_3_close;
	}

	public String getWarning_tone() {
		return warning_tone;
	}

	public void setWarning_tone(String warning_tone) {
		this.warning_tone = warning_tone;
	}

	public int getAdmin_ID() {
		return admin_ID;
	}

	public void setAdmin_ID(int admin_ID) {
		this.admin_ID = admin_ID;
	}

	public int getUserStatus() {
		return userStatus;
	}

	public void setUserStatus(int userStatus) {
		this.userStatus = userStatus;
	}

	public int getService_ID() {
		return service_ID;
	}

	public void setService_ID(int service_ID) {
		this.service_ID = service_ID;
	}

	public int getServiceStatus() {
		return serviceStatus;
	}

	public void setServiceStatus(int serviceStatus) {
		this.serviceStatus = serviceStatus;
	}

	public int getOpen_status() {
		return open_status;
	}

	public void setOpen_status(int open_status) {
		this.open_status = open_status;
	}

	public int getMonth_sales() {
		return month_sales;
	}

	public void setMonth_sales(int month_sales) {
		this.month_sales = month_sales;
	}

	public int getLast_month_sales() {
		return last_month_sales;
	}

	public void setLast_month_sales(int last_month_sales) {
		this.last_month_sales = last_month_sales;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		
		builder.append("RestaurantInfo");
		builder.append(" [ ");
		builder.append("r_ID=" + r_ID);
		builder.append(", home_ID=" + home_ID);
		builder.append(", logo_url=" + logo_url);
		builder.append(", name=" + name);
		builder.append(", address=" + address);
		builder.append(", descr=" + descr);
		builder.append(", phone=" + phone);
		builder.append(", promotion_info=" + promotion_info);
		builder.append(", deliver_desc=" + deliver_desc);
		builder.append(", agent_fee=" + agent_fee);
		builder.append(", isOpen=" + isOpen);
		builder.append(", is_bookable=" + is_bookable);
		builder.append(", time_1_open=" + time_1_open);
		builder.append(", time_1_close=" + time_1_close);
		builder.append(", time_2_open=" + time_2_open);
		builder.append(", time_2_close=" + time_2_close);
		builder.append(", time_3_open=" + time_3_open);
		builder.append(", time_3_close=" + time_3_close);
		builder.append(", warning_tone=" + warning_tone);
		builder.append(", admin_ID=" + admin_ID);
		builder.append(", userStatus=" + userStatus);
		builder.append(", service_ID=" + service_ID);
		builder.append(", serviceStatus=" + serviceStatus);
		builder.append(", open_status=" + open_status);
		builder.append(", month_sales=" + month_sales);
		builder.append(", last_month_sales" + last_month_sales);
		builder.append(" ]");

		return builder.toString();
	}

}
